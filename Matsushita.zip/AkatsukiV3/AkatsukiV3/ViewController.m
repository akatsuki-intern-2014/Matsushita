//
//  ViewController.m
//  AkatsukiV3
//
//  Created by 松下 達也 on 2014/12/14.
//  Copyright (c) 2014年 松下 達也. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    /*
    // サーバーへのリクエストを確立
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:@"http://yutam.tk/server/articles/category"]];
    
    // URLからJSONデータを取得(NSData)
    NSData *jsonData = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
    NSError* error = nil;
    
    NSDictionary *jsonObj = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingAllowFragments error:&error];
    
    
    NSDictionary *array = [ jsonObj objectForKey:@"Status" ];
    NSLog( @"%@", array );
    NSLog( @"message : %@", [ array objectForKey:@"message" ] );
     */
    
    //self.navigationController.navigationBar.tintColor = [ UIColor whiteColor ];
    //self.navigationController.navigationBar.backgroundColor = [ UIColor redColor ];
    
    self.navigationItem.title = @"HOME";
    //[UINavigationBar appearance].barTintColor = [UIColor colorWithRed: 251 green: 225 blue: 236 alpha:10.0];
    
    
    UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithImage:[[UIImage imageNamed:@"back_button.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]
                                                             style:UIBarButtonItemStylePlain
                                                            target:self
                                                            action:@selector(backToScene)];
    //遷移する前にタイトルを設定しておく
    [self.navigationItem setBackBarButtonItem: item];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) backToScene
{
    
}

@end
