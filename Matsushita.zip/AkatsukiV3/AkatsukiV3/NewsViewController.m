//
//  NewsViewController.m
//  AkatsukiV3
//
//  Created by 松下 達也 on 2014/12/14.
//  Copyright (c) 2014年 松下 達也. All rights reserved.
//

#import "NewsViewController.h"

@interface NewsViewController ()

@end

@implementation NewsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    _likeButton.backgroundColor = [ UIColor colorWithRed:255 green:50 blue:50 alpha:0.0 ];
    
    // メイン画像
    NSString *imgFilePath = [ [ _article objectForKey:@"Article" ] objectForKey:@"""image_url""" ];
    
    NSURL *urlPath = [NSURL URLWithString:imgFilePath];
    NSData *data = [NSData dataWithContentsOfURL:urlPath];
    UIImage *image = [UIImage imageWithData:data];
    
    _mainView.contentMode = UIViewContentModeScaleAspectFill;
    _mainView.image = image;
    
    // サーバーへのリクエストを確立
    NSString *articleID = [ [ _article objectForKey:@"Article" ] objectForKey:@"id" ];
    NSLog( @"ID は %@", articleID );
    NSString *url = [ NSString stringWithFormat:@"http://yutam.tk/server/articles/detail/%@", articleID ];
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:url ] ];
    // URLからJSONデータを取得(NSData)
    NSData *jsonData = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
    NSError* error = nil;
    NSDictionary *jsonObj = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingAllowFragments error:&error];
    
    // 記事情報を記録
    _article = [ jsonObj objectForKey:@"Article" ];
    
    // タイトルラベル
    _titleLabel.text = [ _article objectForKey:@"title" ];
    
    // 生成時刻ラベル
    _timeLabel.text = [ _article objectForKey:@"created" ];
    
    // 記事ラベル
    /*
    // タイトル（大きい文字）
    NSString* titleText = [ _article objectForKey:@"title" ];
    NSDictionary *stringAttributes1 = @{ NSForegroundColorAttributeName : [UIColor blackColor],
                                         NSFontAttributeName : [UIFont systemFontOfSize:25.0f] };
    NSAttributedString *string1 = [[NSAttributedString alloc] initWithString:titleText
                                                                  attributes:stringAttributes1];
    // 本文
    NSString* summaryText = [ _article objectForKey:@"body" ];
    NSDictionary *stringAttributes2 = @{ NSForegroundColorAttributeName : [UIColor blackColor],
                                         NSFontAttributeName : [UIFont boldSystemFontOfSize:16.0f] };
    NSAttributedString *string2 = [[NSAttributedString alloc] initWithString:summaryText
                                                                  attributes:stringAttributes2];
    // 結合
    
    NSMutableAttributedString *mutableAttributedString = [[NSMutableAttributedString alloc] init];
    [mutableAttributedString appendAttributedString:string1];
    [mutableAttributedString appendAttributedString:string2];
     */
    
    // テキストの編集を不可にする
    _summaryLabel.editable = NO;
    // テキストを左寄せにする
    _summaryLabel.textAlignment = UITextAlignmentLeft;
    // テキストのフォントを設定
    _summaryLabel.font = [UIFont fontWithName:@"Helvetica" size:14];
    // テキストの背景色を設定
    _summaryLabel.backgroundColor = [UIColor whiteColor];
    // 本文挿入
    _summaryLabel.text = [ _article objectForKey:@"body" ];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

//- (IBAction)tapBackButton:(id)sender {
    //[ self dismissModalViewControllerAnimated:YES];
//}

/*
 * 戻るボタンを押した
 */
- (IBAction)tapBackButton:(UIButton *)sender {
    [ self dismissViewControllerAnimated: YES completion:nil ];
}

/*
 * いいねボタンを押した
 */
- (IBAction)tapLikeButton:(id)sender {
    // サーバーへのリクエストを確立
    NSString *articleID = [ _article objectForKey:@"id" ];
    NSString *url = [ NSString stringWithFormat:@"http://yutam.tk/server/articles/like/%@", articleID ];
    NSURLRequest *request = [ NSURLRequest requestWithURL:[NSURL URLWithString:url ] ];
    // 送信
    [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
    NSLog( @"Your tapped the LIKE button." );
}
@end
