//
//  main.m
//  AkatsukiV3
//
//  Created by 松下 達也 on 2014/12/14.
//  Copyright (c) 2014年 松下 達也. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
