//
//  NewsViewController.h
//  AkatsukiV3
//
//  Created by 松下 達也 on 2014/12/14.
//  Copyright (c) 2014年 松下 達也. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewsViewController : UIViewController
//- (IBAction)tapBackButton:(id)sender;
- (IBAction)tapBackButton:(UIButton *)sender;
@property (weak, nonatomic) IBOutlet UIImageView *mainView;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UITextView *summaryLabel;
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;
@property (weak, nonatomic) IBOutlet UIButton *likeButton;

- (IBAction)tapLikeButton:(id)sender;

@property NSDictionary* article;    // 記事本体のデータ

@end
