//
//  TableViewController.m
//  AkatsukiV3
//
//  Created by 松下 達也 on 2014/12/14.
//  Copyright (c) 2014年 松下 達也. All rights reserved.
//

#import "TableViewController.h"
#import "NewsHeader.h"

@interface TableViewController ()

@end

@implementation TableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    self.tableView.rowHeight = 250.0f;
    self.tableView.separatorColor = [ UIColor orangeColor ];
    self.tableView.scrollEnabled = YES;
    self.navigationItem.title = @"年代別";
    
    // カテゴリーの問い合わせ
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:@"http://yutam.tk/server/articles/category"]];
    // URLからJSONデータを取得(NSData)
    NSData *jsonData = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
    NSError* error = nil;
    NSDictionary *jsonObj = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingAllowFragments error:&error];
    
    // カテゴリー記録
    _categories = [ jsonObj objectForKey: @"Category" ];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    return _categories.count-1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"Cell"];
    }
    
    NSLog( @"%@", _categories );
    
    NSString *context;
    switch( indexPath.row )
    {
        case 0: context = [ _categories objectForKey: @"1" ]; break;
        case 1: context = [ _categories objectForKey: @"2" ]; break;
        case 2: context = [ _categories objectForKey: @"3" ]; break;
        case 3: context = [ _categories objectForKey: @"4" ]; break;
        case 4: context = [ _categories objectForKey: @"5" ]; break;
        case 5: context = [ _categories objectForKey: @"6" ]; break;
        case 6: context = [ _categories objectForKey: @"7" ]; break;
        case 7: context = [ _categories objectForKey: @"8" ]; break;
        case 8: context = @"3歳"; break;
        default: context = @"???"; break;
    }
    //cell.textLabel.text = context;
    cell.textLabel.font = [ UIFont systemFontOfSize: 40 ];
    cell.textLabel.textAlignment = UITextAlignmentCenter;
    
    // Set backgroundView
    NSString *imageName;
    switch( indexPath.row )
    {
        case 0: imageName = @"cell_bg_10.png"; break;
        case 1: imageName = @"cell_bg_4.png"; break;
        case 2: imageName = @"cell_bg_8.png"; break;
        case 3: imageName = @"cell_bg_9.png"; break;
        case 4: imageName = @"cell_bg_11.png"; break;
        case 5: imageName = @"cell_bg_7.png"; break;
        case 6: imageName = @"cell_bg_6.png"; break;
        //case 7: imageName = @"cell_bg.png"; break;
        //case 8: imageName = @"cell_bg.png"; break;
        default: imageName = @"cell_bg.png"; break;
    }
    UIImageView *imageView;
    UIImage *image;
    image = [UIImage imageNamed:imageName];
    imageView = [[UIImageView alloc] initWithImage:image];
    cell.backgroundView = imageView;
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [ self performSegueWithIdentifier: @"toNewsHeader" sender: self ];
    
    //NewsHeader *secondVC = [self.storyboard instantiateViewControllerWithIdentifier:@"NewsHeader"];
    //if( secondVC )
    //    [self presentViewController:secondVC animated:YES completion:nil];//YESならModal,Noなら何もなし
    //else
    //    NSLog( @"NULL!!" );
    //[self presentViewController:secondVC animated:YES completion:nil];//YESならModal,Noなら何もなし
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([[segue identifier] isEqualToString:@"toNewsHeader"]) {
        NSLog( @"categoryIDを%ldにセット", [self.tableView indexPathForSelectedRow].row+1 );
        NewsHeader *newsHeader = [segue destinationViewController];    // <- 1
        newsHeader.categoryID = [self.tableView indexPathForSelectedRow].row + 1;    // <- 2
        NSString *objectForKey = [ NSString stringWithFormat:@"%ld", newsHeader.categoryID ];
        newsHeader.categoryName = [ _categories objectForKey:objectForKey ];
    }
}

- (IBAction)MyPageButton:(id)sender {
    UIViewController *controller = [ [ self storyboard ] instantiateViewControllerWithIdentifier:@"MyPage" ];
    [self.navigationController pushViewController:controller animated:NO];
}
@end
