//
//  NewsHeader.m
//  AkatsukiV3
//
//  Created by 松下 達也 on 2014/12/14.
//  Copyright (c) 2014年 松下 達也. All rights reserved.
//

#import "NewsHeader.h"
#import "NewsViewController.h"
#import "RankingTableViewController.h"

@interface NewsHeader ()

@end

@implementation NewsHeader

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    self.tableView.rowHeight = 60.0f;
    self.tableView.scrollEnabled = YES;
    self.navigationItem.title = _categoryName;
    
    //NSLog( @"testNum には%ldの値が入っています。", _testNum );
    
    // サーバーからカテゴリーIDに応じた記事を持ってくる
    NSString *url = [ NSString stringWithFormat:@"http://yutam.tk/server/articles/lists/%ld", _categoryID ];
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:url]];
    // URLからJSONデータを取得(NSData)
    NSData *jsonData = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
    NSError* error = nil;
    _jsonObj = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingAllowFragments error:&error];
    NSLog( @"%@", _jsonObj );
    
    UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithImage:[[UIImage imageNamed:@"home_button.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]
                                                             style:UIBarButtonItemStylePlain
                                                            target:self
                                                            action:@selector(HomeButton)];
    UIImage *image = [UIImage imageNamed:@"home_button.png" ];
    [ _HomeButton setImage:image forState:UIControlStateNormal ];
    
    UIImage *backgroundImage = [UIImage imageNamed:@"back_pattern.png"];
    self.tableView.backgroundView = [[UIImageView alloc] initWithImage:backgroundImage];
    
    // ニュースの数を取得
    _numOfNews = [ _jsonObj count ] - 1;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    return _numOfNews;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *CellIdentifier = @"HeadLine";
    // tableCell の ID で UITableViewCell のインスタンスを生成
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"Cell"];
    }
    
    // jsonObj から記事を1つ分読み出す
    NSString *articleID = [ NSString stringWithFormat:@"%ld", indexPath.row ];
    NSDictionary* articleData = [ _jsonObj objectForKey: articleID ];
    
    // Set backgroundView
    cell.backgroundColor = [ UIColor colorWithRed:255 green:255 blue:255 alpha:0.45 ];
    
    // 画像の設定
    NSString *imgFilePath = [ [ articleData objectForKey:@"Article" ] objectForKey:@"""image_url""" ];
    NSURL *url = [NSURL URLWithString:imgFilePath];
    NSData *data = [NSData dataWithContentsOfURL:url];
    UIImage *image = [UIImage imageWithData:data];
    
    // Tag番号 1 で UIImageView インスタンスの生成
    UIImageView *imageView = (UIImageView *)[cell viewWithTag:1];
    imageView.contentMode = UIViewContentModeScaleToFill;
    imageView.image = image;

    // Tag番号 ２ で タイトルの生成
    UILabel *label1 = (UILabel *)[cell viewWithTag:2];
    NSString *titleText = [ [ articleData objectForKey:@"Article" ] objectForKey:@"title" ];
    label1.text = [NSString stringWithFormat:titleText, (int)(indexPath.row+1) ];
    
    // Tag番号 ３ で UILabel インスタンスの生成
    UILabel *label2 = (UILabel *)[cell viewWithTag:3];
    NSString *dataText = [ [ articleData objectForKey:@"Article" ] objectForKey:@"created" ];
    label2.text = dataText;
    
    // Tag番号 4 でいいね数の生成
    NSString *likeNum = [ [ articleData objectForKey:@"Like" ] objectForKey:@"value" ];
    UILabel *label3 = (UILabel *)[ cell viewWithTag: 4 ];
    label3.text = [ NSString stringWithFormat:@"%@", likeNum ];
    
    
    return cell;
}

/*
 * Cellを選択した時の動作
 */
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [ self performSegueWithIdentifier: @"toNews" sender: self ];
}

/*
 * セグエ遷移前の準備
 */
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([[segue identifier] isEqualToString:@"toNews"]) {
        NewsViewController *newsViewController = [segue destinationViewController];    // <- 1
        
        NSUInteger number = [ self.tableView indexPathForSelectedRow ].row;
        NSString *articleID = [ NSString stringWithFormat: @"%ld", number ];
        newsViewController.article = [ _jsonObj objectForKey:articleID ];
    } else if( [ [ segue identifier ] isEqualToString:@"toRanking" ] ) {
        NSLog( @"入りました" );
        RankingTableViewController* nextView = [ segue destinationViewController ];
        nextView.jsonObj = _jsonObj;
        nextView.numOfNews = _numOfNews;
    }
}

/*
 * 再び現れたときにデータを読み込み直す
 */
- (void)viewWillAppear:(BOOL)animated
{
    [self.tableView reloadData];
    [super viewWillAppear:animated];
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)HomeButton:(id)sender {
    UIViewController *controller = [ [ self storyboard ] instantiateViewControllerWithIdentifier:@"TableViewController" ];
    [self.navigationController pushViewController:controller animated:YES];
}
@end
